import socket
import time
from uuid import uuid4

DEFAULT_HOST = "localhost"
DEFAULT_PORT = 8879
BUFFER_SIZE = 8192
INTERVAL = 2

class PyccuracyClient(object):
    def __init__(self, host=DEFAULT_HOST, port=DEFAULT_PORT):
        self.identifier = uuid4()
        self.host = host
        self.port = port

    def keep_alive(self):
        print "Trying to Connect to Server"
        while True:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.connect((self.host, self.port))
                self.shake_hands(sock)
                self.handle_connection(sock)
                sock.close()
                time.sleep(INTERVAL)
            except socket.error, err:
                code, message = err.args
                if code != 111 or message != "Connection refused":
                    raise
            except KeyboardInterrupt:
                break;

    def shake_hands(self, sock):
        print "Identifying as %s" % self.identifier
        sock.sendall("@identifier=%s\n" % self.identifier)

    def handle_connection(self, sock):
        data = """A few lines of data
        to test the operation
        of both server and client"""
        
        for line in data.splitlines():
            sock.sendall(line + "\n")
            print "Sent %s" % line
            response = sock.recv(BUFFER_SIZE)
            print "Received %s" % response

if __name__ == "__main__":
    client = PyccuracyClient()
    client.keep_alive()
