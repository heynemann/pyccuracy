#import asyncore
#from asynchat import async_chat
import socket

DEFAULT_PORT = 8879
BUFFER_SIZE = 8192

class PyccuracyServer(object):
    def start(self, port=DEFAULT_PORT):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind(('', port))
        self.server_socket.listen(5)
        print "Server started..."
        self.keep_listening()
        
    def stop(self):
        self.server_socket.close()
        print "Server stopped."

    def keep_listening(self):
        print "Listening..."
        while True:
            client_socket, address = self.server_socket.accept()
            print "Connected to", address
            message = []
            while True:
                received_data = client_socket.recv(BUFFER_SIZE)
                if not received_data: break
                message.append(received_data)
                if "\n" in received_data: break
            self.handle_message(client_socket, "".join(message))
            client_socket.close()
            print "Disconnected from", address

    def handle_message(self, client_socket, message):
        print "sending back %s" % message
        client_socket.sendall(message)

if __name__ == "__main__":
    srv = PyccuracyServer()
    try:
        srv.start()
    except KeyboardInterrupt:
        srv.stop()
