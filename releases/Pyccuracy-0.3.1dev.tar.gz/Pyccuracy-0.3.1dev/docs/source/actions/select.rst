======================
Select Actions Grammar
======================

.. toctree::
   :maxdepth: 2
   :glob:

   select/*