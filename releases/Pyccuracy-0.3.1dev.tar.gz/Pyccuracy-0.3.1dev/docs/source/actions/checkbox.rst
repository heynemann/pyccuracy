========================
Checkbox Actions Grammar
========================

.. toctree::
   :maxdepth: 2
   :glob:

   checkbox/*