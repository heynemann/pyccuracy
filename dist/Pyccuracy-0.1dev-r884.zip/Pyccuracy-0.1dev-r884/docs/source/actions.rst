=========================
Test Language Definitions
=========================

Below you can find the different groups of actions that Pyccuracy supports.

Under each action group you can see the syntax used for performing some action. 
If you need more detail about it, just click the desired action, or click the action group to know more about it.

.. toctree::
   :maxdepth: 2
   :glob:

   actions/*